﻿namespace ConverteWordEmPdf
{
    partial class ConverteWordToPdf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnexecutar = new System.Windows.Forms.Button();
            this.btnarquivo = new System.Windows.Forms.Button();
            this.labelresultado = new System.Windows.Forms.Label();
            this.labelselecionado = new System.Windows.Forms.Label();
            this.textNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnpasta = new System.Windows.Forms.Button();
            this.labelpasta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 267);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Salvar Nome :";
            // 
            // btnexecutar
            // 
            this.btnexecutar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnexecutar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnexecutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexecutar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnexecutar.Location = new System.Drawing.Point(446, 310);
            this.btnexecutar.Name = "btnexecutar";
            this.btnexecutar.Size = new System.Drawing.Size(209, 55);
            this.btnexecutar.TabIndex = 1;
            this.btnexecutar.Text = "Converter";
            this.btnexecutar.UseVisualStyleBackColor = false;
            this.btnexecutar.Click += new System.EventHandler(this.btnexecutar_Click);
            // 
            // btnarquivo
            // 
            this.btnarquivo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnarquivo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnarquivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnarquivo.ForeColor = System.Drawing.SystemColors.Control;
            this.btnarquivo.Location = new System.Drawing.Point(446, 254);
            this.btnarquivo.Name = "btnarquivo";
            this.btnarquivo.Size = new System.Drawing.Size(209, 38);
            this.btnarquivo.TabIndex = 2;
            this.btnarquivo.Text = "Arquivo";
            this.btnarquivo.UseVisualStyleBackColor = false;
            this.btnarquivo.Click += new System.EventHandler(this.btnarquivo_Click);
            // 
            // labelresultado
            // 
            this.labelresultado.AutoSize = true;
            this.labelresultado.ForeColor = System.Drawing.SystemColors.Control;
            this.labelresultado.Location = new System.Drawing.Point(194, 352);
            this.labelresultado.Name = "labelresultado";
            this.labelresultado.Size = new System.Drawing.Size(68, 13);
            this.labelresultado.TabIndex = 3;
            this.labelresultado.Text = "Aguardando:";
            // 
            // labelselecionado
            // 
            this.labelselecionado.AutoSize = true;
            this.labelselecionado.ForeColor = System.Drawing.SystemColors.Control;
            this.labelselecionado.Location = new System.Drawing.Point(198, 288);
            this.labelselecionado.Name = "labelselecionado";
            this.labelselecionado.Size = new System.Drawing.Size(101, 13);
            this.labelselecionado.TabIndex = 4;
            this.labelselecionado.Text = "Nada Selecionado :";
            // 
            // textNome
            // 
            this.textNome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textNome.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNome.ForeColor = System.Drawing.Color.White;
            this.textNome.Location = new System.Drawing.Point(123, 259);
            this.textNome.Name = "textNome";
            this.textNome.Size = new System.Drawing.Size(317, 26);
            this.textNome.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(120, 288);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Selecionado :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(120, 352);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Resultado :";
            // 
            // btnpasta
            // 
            this.btnpasta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnpasta.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnpasta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpasta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpasta.ForeColor = System.Drawing.Color.White;
            this.btnpasta.Location = new System.Drawing.Point(15, 310);
            this.btnpasta.Name = "btnpasta";
            this.btnpasta.Size = new System.Drawing.Size(94, 31);
            this.btnpasta.TabIndex = 9;
            this.btnpasta.Text = "Pasta";
            this.btnpasta.UseVisualStyleBackColor = false;
            this.btnpasta.Click += new System.EventHandler(this.btnpasta_Click);
            // 
            // labelpasta
            // 
            this.labelpasta.AutoSize = true;
            this.labelpasta.Location = new System.Drawing.Point(120, 319);
            this.labelpasta.Name = "labelpasta";
            this.labelpasta.Size = new System.Drawing.Size(87, 13);
            this.labelpasta.TabIndex = 10;
            this.labelpasta.Text = "Pasta De Saida :";
            // 
            // ConverteWordToPdf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(664, 431);
            this.Controls.Add(this.labelpasta);
            this.Controls.Add(this.btnpasta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textNome);
            this.Controls.Add(this.labelselecionado);
            this.Controls.Add(this.labelresultado);
            this.Controls.Add(this.btnarquivo);
            this.Controls.Add(this.btnexecutar);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.MaximizeBox = false;
            this.Name = "ConverteWordToPdf";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Converte Word para Pdf";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnexecutar;
        private System.Windows.Forms.Button btnarquivo;
        private System.Windows.Forms.Label labelresultado;
        private System.Windows.Forms.Label labelselecionado;
        private System.Windows.Forms.TextBox textNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnpasta;
        private System.Windows.Forms.Label labelpasta;
    }
}

