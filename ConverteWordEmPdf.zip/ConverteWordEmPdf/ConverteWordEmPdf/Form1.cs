﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Word;


namespace ConverteWordEmPdf
{
    public partial class ConverteWordToPdf : Form
    {
        private FolderBrowserDialog folderBrowserDialog;
        public string pasta = "Pasta De Saida :";
        public ConverteWordToPdf()
        {
            InitializeComponent();
        }

        private void btnarquivo_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            if (DialogResult.OK == dialog.ShowDialog())
            {
                labelselecionado.Text = dialog.FileName;

            }
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
           
            try
            {
                if (labelselecionado.Text != "Nada Selecionado :")
                {
                    
               
                labelresultado.Text = "Convertendo...";
                string nomesaida = textNome.Text;
                Microsoft.Office.Interop.Word.Application app = new Microsoft.Office.Interop.Word.Application();

                Document doc = app.Documents.Open(labelselecionado.Text);
                if (labelpasta.Text == "Pasta De Saida :")
                {
                   labelpasta.Text = "Documentos";
                }
                string pasta = labelpasta.Text;

                doc.SaveAs(pasta +"\\"+ nomesaida + ".pdf", WdSaveFormat.wdFormatPDF);

                ///apos salvo feche tudo
                doc.Close();
                app.Quit();
                
                }
                else
                {
                    labelselecionado.Text = "Escolha um Arquivo !";
                    return;
                }
            }
            catch (Exception ex)
            {
                labelresultado.Text = ex.Message;
            }
            finally
            {
                if (labelresultado.Text == "Convertendo...")
                {
                    string nomesaida = textNome.Text;
                    string pasta = labelpasta.Text;
                    labelresultado.Text = "Arquivo Convertido !\n "+"salvo em :"+ pasta +"\\"+ nomesaida + ".pdf";
                }
                else
                {
                    labelresultado.Text = " Tenta de Novo... !";
                }
               
            }
        }
       
            private void btnpasta_Click(object sender, EventArgs e)
            {

                this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
          
                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                 labelpasta.Text = folderBrowserDialog.SelectedPath;
                }
            

            }
      
    }
}
